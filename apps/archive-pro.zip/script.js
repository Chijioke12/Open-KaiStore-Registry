// Extracted from script tag 1
let currentView = 'search';
        let currentType = 'movies';
        let history = JSON.parse(localStorage.getItem('ia_history') || '[]');

        function showToast(msg) {
            const t = document.createElement("div");
            t.className = "toast"; t.innerHTML = msg;
            document.body.appendChild(t);
            setTimeout(() => { if(t.parentNode) t.parentNode.removeChild(t) }, 3000);
        }

        function centerElement(el) {
            if (!el) return;
            const container = document.getElementById('view-container');
            const offset = el.offsetTop - container.offsetTop;
            container.scrollTop = offset - (container.clientHeight / 2) + (el.clientHeight / 2);
            el.focus();
        }

        function navigate(dir) {
            const items = document.querySelectorAll('.focusable:not([style*="display: none"])');
            let idx = Array.prototype.indexOf.call(items, document.activeElement);
            if (idx === -1) idx = 0;
            let next = idx + dir;
            if (next >= items.length) next = 0;
            if (next < 0) next = items.length - 1;
            centerElement(items[next]);
        }

        function updateHistory(q) {
            if(!q || history.includes(q)) return;
            history.unshift(q);
            if(history.length > 6) history.pop();
            localStorage.setItem('ia_history', JSON.stringify(history));
            renderHistory();
        }

        function renderHistory() {
            const box = document.getElementById('history-box');
            box.innerHTML = history.length ? '<div style="width:100%;font-size:10px;margin-bottom:5px">RECENT:</div>' : '';
            history.forEach(h => {
                const s = document.createElement('div');
                s.className = 'hist-tag focusable';
                s.tabIndex = 0;
                s.innerText = h;
                s.onclick = () => { document.getElementById('search-input').value = h; performSearch(); };
                box.appendChild(s);
            });
        }

        function performSearch() {
            const query = document.getElementById('search-input').value;
            if(!query) return showToast("Enter keywords");
            updateHistory(query);

            currentView = 'results';
            document.getElementById('search-view').style.display = 'none';
            const list = document.getElementById('results-list');
            list.style.display = 'block';
            list.innerHTML = '<div class="info-box">Searching Archive.org...</div>';
            document.getElementById('sk-left').innerText = "BACK";

            const url = `https://archive.org/advancedsearch.php?q=${encodeURIComponent(query)}+AND+mediatype:${currentType}&fl[]=identifier,title,mediatype&rows=25&output=json`;
            const xhr = new XMLHttpRequest({ mozSystem: true });
            xhr.open('GET', url);
            xhr.onload = () => {
                const data = JSON.parse(xhr.responseText);
                list.innerHTML = "";
                if(!data.response.docs.length) { list.innerHTML = "No results found."; return; }
                data.response.docs.forEach((item, i) => {
                    const div = document.createElement('div');
                    div.className = "list-item focusable";
                    div.tabIndex = i;
                    const thumb = `https://archive.org/services/img/${item.identifier}`;
                    div.innerHTML = `<img src="${thumb}"><div class="meta"><div class="sub">${item.mediatype}</div><div class="title">${item.title}</div></div>`;
                    div.onclick = () => fetchFiles(item.identifier, item.title);
                    list.appendChild(div);
                });
                if(list.firstChild) list.firstChild.focus();
            };
            xhr.send();
        }

        function fetchFiles(id, title) {
            const list = document.getElementById('results-list');
            list.innerHTML = `<div class="info-box">Loading files for:<br>${title}</div>`;
            const xhr = new XMLHttpRequest({ mozSystem: true });
            xhr.open('GET', `https://archive.org/metadata/${id}`);
            xhr.onload = () => {
                const data = JSON.parse(xhr.responseText);
                list.innerHTML = `<div class="info-box"><b>${title}</b></div>`;
                let count = 0;
                data.files.forEach(f => {
                    if(f.name.match(/\.(mp4|mp3|pdf|epub|zip|mkv|jpg|png|txt)$/i) && !f.name.includes('_archive.torrent')) {
                        const div = document.createElement('div');
                        div.className = "list-item focusable";
                        div.tabIndex = count++;
                        const isAudio = f.name.endsWith('.mp3');
                        const sizeMB = (f.size/1024/1024).toFixed(1);
                        div.innerHTML = `<div class="meta"><div class="title">${f.name.slice(-25)}</div><div class="sub">${sizeMB} MB | ${f.format || ''}</div></div>`;
                        
                        const dlUrl = `https://${data.server}${data.dir}/${f.name}`;
                        div.onclick = () => {
                            if(isAudio && confirm("Play audio stream?")) {
                                document.getElementById('player-ui').style.display = 'block';
                                document.getElementById('player-name').innerText = f.name;
                                const aud = document.getElementById('main-audio');
                                aud.src = dlUrl; aud.play();
                            } else {
                                checkSpace(dlUrl, f.name, f.size);
                            }
                        };
                        list.appendChild(div);
                    }
                });
                if(list.querySelector('.focusable')) list.querySelector('.focusable').focus();
            };
            xhr.send();
        }

        function checkSpace(url, name, size) {
            try {
                const sd = navigator.getDeviceStorage('sdcard');
                const req = sd.freeSpace();
                req.onsuccess = function() {
                    if (this.result < size) alert("No space on SD Card!");
                    else triggerDL(url, name);
                };
                req.onerror = () => triggerDL(url, name);
            } catch(e) { triggerDL(url, name); }
        }

        function triggerDL(url, name) {
            showToast("Sending to manager...");
            const iframe = document.createElement('iframe');
            iframe.setAttribute('mozbrowser', 'true');
            iframe.style.display = 'none';
            document.body.appendChild(iframe);
            setTimeout(() => {
                const req = iframe.download(url, { filename: name });
                req.onsuccess = () => showToast("Downloading...");
                req.onerror = () => window.open(url, '_blank');
            }, 500);
        }

        document.addEventListener('keydown', (e) => {
            switch(e.key) {
                case 'ArrowDown': navigate(1); break;
                case 'ArrowUp': navigate(-1); break;
                case 'ArrowRight':
                case 'ArrowLeft':
                    if(currentView === 'search' && document.activeElement.tagName !== 'INPUT') {
                        const opts = document.querySelectorAll('.filter-opt');
                        let idx = Array.from(opts).findIndex(o => o.classList.contains('active'));
                        opts[idx].classList.remove('active');
                        idx = (e.key === 'ArrowRight') ? (idx + 1) % opts.length : (idx - 1 + opts.length) % opts.length;
                        opts[idx].classList.add('active');
                        currentType = opts[idx].dataset.type;
                    }
                    break;
                case 'Enter': document.activeElement.click(); break;
                case 'Backspace':
                case 'Clear':
                    if(document.activeElement.tagName === 'INPUT') return;
                    e.preventDefault();
                    if(currentView === 'results') {
                        document.getElementById('player-ui').style.display = 'none';
                        document.getElementById('main-audio').pause();
                        showSearch();
                    } else window.close();
                    break;
                case 'SoftLeft':
                    if(currentView === 'results') showSearch();
                    break;
                case 'SoftRight': window.close(); break;
            }
        });

        function showSearch() {
            currentView = 'search';
            document.getElementById('search-view').style.display = 'block';
            document.getElementById('results-list').style.display = 'none';
            document.getElementById('sk-left').innerText = "FILTER";
            renderHistory();
            document.getElementById('search-input').focus();
        }

        document.getElementById('search-btn').onclick = performSearch;
        window.onload = () => { renderHistory(); document.getElementById('search-input').focus(); };