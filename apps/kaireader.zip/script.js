// Extracted from script tag 1
const ICON_TXT = `<svg class="file-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><line x1="10" y1="9" x2="8" y2="9"></line></svg>`;

        // Error Catcher
        window.onerror = function(msg, url, line) {
            const errDiv = document.getElementById('error-display');
            errDiv.style.display = 'block';
            errDiv.innerHTML = "<h3>Error</h3><p>" + msg + "</p><p>Line: " + line + "</p>";
        };

        document.addEventListener("DOMContentLoaded", () => {
            const state = {
                view: 'home', file: null, fileSize: 0, currentOffset: 0, chunkSize: 5000, 
                fontSize: 14, themeIndex: 0, themes: ['theme-light', 'theme-dark', 'theme-sepia'],
                allFiles: [], filteredFiles: [], lastInputTime: 0, isSearchOpen: false
            };

            const els = {
                views: { home: document.getElementById('view-home'), reader: document.getElementById('view-reader') },
                fileList: document.getElementById('file-list-container'),
                statusMsg: document.getElementById('status-msg'),
                searchContainer: document.getElementById('search-container'),
                searchInput: document.getElementById('search-input'),
                readerContent: document.getElementById('reader-content'),
                readerTitle: document.getElementById('reader-title'),
                loader: document.getElementById('loader'),
                menu: document.getElementById('menu-overlay'),
                softkeys: {
                    // FIX: Using Array.from() fixes the "forEach is not a function" error on KaiOS
                    left: Array.from(document.querySelectorAll('.softkey.left')),
                    center: Array.from(document.querySelectorAll('.softkey.center')),
                    right: Array.from(document.querySelectorAll('.softkey.right'))
                }
            };

            let navItems = [];
            let navIndex = 0;

            loadSettings();
            scanForFiles();
            window.addEventListener('keydown', handleKeydown);
            els.searchInput.addEventListener('input', (e) => filterFiles(e.target.value));

            // --- GECKO 48 COMPATIBLE SCROLLING ---
            function scrollToCenter(element) {
                if (!element) return;
                const parent = element.parentElement; 
                if (!parent) return;
                const elTop = element.offsetTop;
                const elHeight = element.clientHeight;
                const parentHeight = parent.clientHeight;
                parent.scrollTop = elTop - (parentHeight / 2) + (elHeight / 2);
            }

            function scanForFiles() {
                els.statusMsg.innerText = "Scanning...";
                state.allFiles = [];
                
                if (navigator.getDeviceStorage) {
                    try {
                        const sdcard = navigator.getDeviceStorage('sdcard');
                        const cursor = sdcard.enumerate();
                        cursor.onsuccess = function () {
                            const file = this.result;
                            if (file) {
                                if (file.name.slice(-4) === '.txt' && file.name[0] !== '.') {
                                    state.allFiles.push(file);
                                }
                                this.continue();
                            } else {
                                finalizeScan();
                            }
                        };
                        cursor.onerror = function () { els.statusMsg.innerText = "Err: Storage Access"; };
                    } catch(e) { els.statusMsg.innerText = "Err: " + e.message; }
                } else {
                    // Simulation
                    state.allFiles.push(createMockFile("Alice.txt", "Chapter 1..."));
                    state.allFiles.push(createMockFile("Notes.txt", "Buy Milk"));
                    finalizeScan();
                }
            }

            function createMockFile(name, content) {
                const b = new Blob([content], {type: 'text/plain'});
                b.name = name; return b;
            }

            function finalizeScan() {
                if (state.allFiles.length === 0) {
                    els.statusMsg.innerText = "No .txt files.";
                } else {
                    els.statusMsg.style.display = 'none';
                    state.filteredFiles = [...state.allFiles];
                    renderFileList();
                }
            }

            function filterFiles(query) {
                const q = query.toLowerCase();
                state.filteredFiles = state.allFiles.filter(f => f.name.split('/').pop().toLowerCase().indexOf(q) > -1);
                renderFileList();
            }

            function renderFileList() {
                els.fileList.innerHTML = "";
                if(state.filteredFiles.length === 0) {
                    els.fileList.innerHTML = "<div style='padding:10px; color:gray'>No matches</div>";
                    navItems = [];
                    return;
                }

                state.filteredFiles.forEach((file, index) => {
                    const div = document.createElement('div');
                    div.className = 'nav-item file-item';
                    div.innerHTML = ICON_TXT + "<span>" + file.name.split('/').pop() + "</span>";
                    div.dataset.index = index;
                    div.onclick = () => {
                        if(state.view === 'home') {
                             if(document.activeElement === els.searchInput) els.searchInput.blur();
                            navIndex = index; updateFocus(); handleEnter();
                        }
                    };
                    els.fileList.appendChild(div);
                });

                refreshNavItems('.file-item');
                if (!state.isSearchOpen) updateFocus();
            }

            function handleKeydown(e) {
                const now = Date.now();
                if (now - state.lastInputTime < 100) { e.preventDefault(); return; }
                state.lastInputTime = now;

                const isSearch = (document.activeElement === els.searchInput);

                switch(e.key) {
                    case 'ArrowDown':
                        if (isSearch) { e.preventDefault(); els.searchInput.blur(); navIndex = 0; updateFocus(); }
                        else if (state.view === 'reader') scrollReader(30);
                        else moveFocus(1);
                        break;
                    case 'ArrowUp':
                        if (state.view === 'home' && state.isSearchOpen && navIndex === 0 && !isSearch) {
                            e.preventDefault();
                            if(navItems[navIndex]) navItems[navIndex].classList.remove('focused');
                            els.searchInput.focus();
                        }
                        else if (state.view === 'reader') scrollReader(-30);
                        else moveFocus(-1);
                        break;
                    case 'Enter':
                    case 'NumpadEnter':
                        if (isSearch) { e.preventDefault(); els.searchInput.blur(); navIndex = 0; updateFocus(); }
                        else handleEnter();
                        break;
                    case 'SoftLeft': case 'F1':
                        if (state.view === 'home') toggleSearch();
                        else if (state.view === 'reader') toggleMenu();
                        break;
                    case 'SoftRight': case 'F2': case 'Backspace':
                        if (!isSearch) handleSoftRight(e);
                        break;
                }
            }

            function refreshNavItems(selector) {
                navItems = Array.from(document.querySelectorAll(selector));
                if (navIndex >= navItems.length) navIndex = Math.max(0, navItems.length - 1);
            }

            function moveFocus(dir) {
                if (state.view === 'reader' || navItems.length === 0) return;
                if (navItems[navIndex]) navItems[navIndex].classList.remove('focused');
                
                navIndex += dir;
                if (navIndex < 0) navIndex = 0;
                if (navIndex >= navItems.length) navIndex = navItems.length - 1;
                
                if (navItems[navIndex]) {
                    navItems[navIndex].classList.add('focused');
                    scrollToCenter(navItems[navIndex]);
                }
            }

            function updateFocus() {
                navItems.forEach(el => el.classList.remove('focused'));
                if (navItems.length > 0 && navItems[navIndex]) {
                    navItems[navIndex].classList.add('focused');
                    scrollToCenter(navItems[navIndex]);
                }
            }

            function toggleSearch() {
                state.isSearchOpen = !state.isSearchOpen;
                if (state.isSearchOpen) {
                    els.searchContainer.style.display = 'block';
                    els.searchInput.focus();
                    updateSoftKeys('Close', '', '');
                    if(navItems[navIndex]) navItems[navIndex].classList.remove('focused');
                } else {
                    els.searchContainer.style.display = 'none';
                    els.searchInput.value = ''; els.searchInput.blur();
                    filterFiles(''); updateSoftKeys('Search', 'OPEN', ''); updateFocus();
                }
            }

            function handleEnter() {
                if (state.view === 'home' && navItems.length > 0) {
                    openFile(state.filteredFiles[parseInt(navItems[navIndex].dataset.index)]);
                } else if (state.view === 'menu') {
                    performMenuAction(navItems[navIndex].dataset.action);
                }
            }

            function handleSoftRight(e) {
                if (state.view === 'menu') toggleMenu();
                else if (state.view === 'reader') { e.preventDefault(); saveProgress(); switchView('home'); }
                else if (state.view === 'home' && state.isSearchOpen) { e.preventDefault(); toggleSearch(); }
            }

            function openFile(file) {
                state.file = file; state.fileSize = file.size;
                els.readerTitle.innerText = file.name.split('/').pop();
                const saved = localStorage.getItem('progress_' + file.name);
                state.currentOffset = saved ? parseInt(saved) : 0;
                switchView('reader'); renderTextChunk();
            }

            function renderTextChunk() {
                els.loader.style.display = 'block';
                const reader = new FileReader();
                const blob = state.file.slice(state.currentOffset, state.currentOffset + state.chunkSize);
                reader.onload = (e) => {
                    els.readerContent.innerText = e.target.result;
                    els.loader.style.display = 'none';
                    els.readerContent.scrollTop = 0;
                };
                reader.readAsText(blob);
            }

            function scrollReader(amount) {
                const el = els.readerContent;
                const wasAtBottom = (el.scrollTop + el.clientHeight >= el.scrollHeight - 10);
                el.scrollTop += amount;
                if (amount > 0 && wasAtBottom) {
                    if (state.currentOffset + state.chunkSize < state.fileSize) {
                        state.currentOffset += state.chunkSize; renderTextChunk();
                    }
                } else if (amount < 0 && el.scrollTop === 0) {
                    if (state.currentOffset > 0) {
                        state.currentOffset = Math.max(0, state.currentOffset - state.chunkSize); renderTextChunk();
                    }
                }
            }

            function toggleMenu() {
                if (state.view === 'menu') {
                    els.menu.style.display = 'none'; state.view = 'reader'; updateSoftKeys('Menu', '', 'Back');
                } else {
                    els.menu.style.display = 'block'; state.view = 'menu';
                    navIndex = 0; refreshNavItems('.menu-item'); updateSoftKeys('', 'SELECT', 'Cancel');
                    navItems.forEach((item, idx) => { item.onclick = () => { navIndex = idx; handleEnter(); } });
                }
            }

            function performMenuAction(action) {
                switch(action) {
                    case 'theme':
                        state.themeIndex = (state.themeIndex + 1) % state.themes.length;
                        document.body.className = state.themes[state.themeIndex];
                        navItems[navIndex].innerText = "Theme: " + state.themes[state.themeIndex].replace('theme-', '');
                        saveSettings(); break;
                    case 'size':
                        state.fontSize = state.fontSize >= 24 ? 12 : state.fontSize + 2;
                        els.readerContent.style.fontSize = state.fontSize + 'px';
                        navItems[navIndex].innerText = "Size: " + (state.fontSize >= 24 ? "Large" : "Medium");
                        saveSettings(); break;
                    case 'jump': state.currentOffset = 0; renderTextChunk(); toggleMenu(); break;
                    case 'close': toggleMenu(); break;
                }
            }

            function switchView(viewName) {
                state.view = viewName;
                els.views.home.classList.remove('active-view');
                els.views.reader.classList.remove('active-view');
                els.views[viewName].classList.add('active-view');
                if (viewName === 'home') {
                    state.isSearchOpen = false; els.searchContainer.style.display = 'none';
                    filterFiles(''); refreshNavItems('.file-item'); updateSoftKeys('Search', 'OPEN', '');
                } else updateSoftKeys('Menu', '', 'Back');
            }

            function updateSoftKeys(l, c, r) {
                els.softkeys.left.forEach(el => el.innerText = l);
                els.softkeys.center.forEach(el => el.innerText = c);
                els.softkeys.right.forEach(el => el.innerText = r);
            }

            function saveProgress() { if(state.file) localStorage.setItem('progress_' + state.file.name, state.currentOffset); }
            function saveSettings() { localStorage.setItem('kaiReaderSettings', JSON.stringify({ theme: state.themeIndex, size: state.fontSize })); }
            function loadSettings() {
                const set = JSON.parse(localStorage.getItem('kaiReaderSettings'));
                if(set) {
                    state.themeIndex = set.theme; state.fontSize = set.size;
                    document.body.className = state.themes[state.themeIndex];
                    els.readerContent.style.fontSize = state.fontSize + 'px';
                }
            }
        });