// Extracted from script tag 1
// --- CONFIG ---
        const BASE_URL = "https://crusadeprayergroup.org/";
        const CACHE_HOME = "cp_home_data";
        const CACHE_PREFIX = "cp_prayer_";
        const CACHE_THEME = "cp_theme_pref";

        // --- GLOBAL VARIABLES ---
        var currentView = 'list';
        var currentIndex = 0; // Integer index (0, 1, 2...)
        var items = [];       // DOM Elements array
        var listScrollContainer = document.getElementById('list-view');

        window.addEventListener('DOMContentLoaded', function() {
            // 1. Theme
            if(localStorage.getItem(CACHE_THEME) === 'dark') document.body.classList.add('dark-mode');

            // 2. Data
            loadHomeFromCache();
            fetchHomeData();

            // 3. Key Handler
            window.addEventListener('keydown', handleKeydown);
        });

        // --- NAVIGATION LOGIC (The Sample Code Logic) ---

        function move(direction) {
            if (items.length === 0) return;

            currentIndex += direction;

            // Circular Logic
            if (currentIndex >= items.length) {
                currentIndex = 0;
            } else if (currentIndex < 0) {
                currentIndex = items.length - 1;
            }

            updateSelection(currentIndex);
        }

        function updateSelection(index) {
            // 1. Clear previous active class
            var prev = document.querySelector('.item.active');
            if (prev) prev.classList.remove('active');

            // 2. Set new active class
            var currentItem = items[index];
            if (currentItem) {
                currentItem.classList.add('active');
                // 3. Scroll to Center (Manual Calculation)
                scrollToCenter(currentItem, listScrollContainer);
            }
        }

        function scrollToCenter(element, container) {
            var elementTop = element.offsetTop;
            var elementHeight = element.offsetHeight;
            var containerHeight = container.clientHeight;

            // The Math from your sample
            var targetScrollPos = elementTop - (containerHeight / 2) + (elementHeight / 2);

            container.scrollTop = targetScrollPos;
        }

        // --- KEY HANDLER ---

        function handleKeydown(e) {
            switch(e.key) {
                case 'ArrowDown':
                    if (currentView === 'list') move(1);
                    else scrollDetail(1);
                    break;

                case 'ArrowUp':
                    if (currentView === 'list') move(-1);
                    else scrollDetail(-1);
                    break;

                // Page Down / Up (Right/Left)
                case 'ArrowRight':
                    if (currentView === 'list') move(6); else scrollDetail(6);
                    break;
                case 'ArrowLeft':
                    if (currentView === 'list') move(-6); else scrollDetail(-6);
                    break;

                case 'Enter':
                case 'NumpadEnter':
                    if (currentView === 'list' && items.length > 0) {
                        var el = items[currentIndex];
                        openPrayer(el.dataset.url, el.dataset.title);
                    }
                    break;

                case 'SoftRight': 
                case 'Backspace': 
                case 'EndCall':
                    e.preventDefault();
                    if (currentView === 'detail') closePrayer();
                    else window.close();
                    break;
                
                case 'SoftLeft':
                    toggleTheme();
                    break;
                
                // Top/Bottom Jump
                case '2':
                    if (currentView === 'list') { currentIndex=0; updateSelection(0); }
                    else document.getElementById('detail-view').scrollTop = 0;
                    break;
                case '8':
                    if (currentView === 'list') { currentIndex=items.length-1; updateSelection(currentIndex); }
                    else { var d=document.getElementById('detail-view'); d.scrollTop=d.scrollHeight; }
                    break;
            }
        }

        function scrollDetail(dir) {
            document.getElementById('detail-view').scrollTop += (dir * 50);
        }

        // --- DATA & UI ---

        function renderList(data) {
            var container = document.getElementById('list-container');
            container.innerHTML = "";
            
            // Generate standard DIVs (not buttons)
            data.forEach(function(item) {
                var div = document.createElement('div');
                div.className = 'item'; // Matches CSS .item
                div.textContent = item.text;
                div.dataset.url = item.url;
                div.dataset.title = item.text;
                container.appendChild(div);
            });

            document.getElementById('loading-msg').style.display = 'none';

            // Refresh DOM list
            items = document.querySelectorAll('.item');
            
            // Reset index if out of bounds
            if (currentIndex >= items.length) currentIndex = 0;
            
            // Initialize Selection
            updateSelection(currentIndex);
        }

        function openPrayer(url, title) {
            currentView = 'detail';
            document.getElementById('app-header').innerText = title;
            document.getElementById('detail-view').style.display = 'block';
            document.getElementById('list-view').style.display = 'none';
            document.getElementById('soft-center').innerText = "";
            document.getElementById('soft-right').innerText = "Back";
            
            // Load content
            var cacheKey = CACHE_PREFIX + url;
            var cached = localStorage.getItem(cacheKey);
            var contentDiv = document.getElementById('detail-content');
            
            if (cached) {
                contentDiv.innerHTML = JSON.parse(cached);
                document.getElementById('detail-view').scrollTop = 0;
            } else {
                contentDiv.innerHTML = "<p>Loading...</p>";
            }

            // Fetch
            var xhr = new XMLHttpRequest({ mozSystem: true });
            xhr.open("GET", url, true);
            xhr.onload = function() {
                if (xhr.status === 200 || xhr.status === 0) {
                    var html = parseDetail(xhr.responseText);
                    if (html) {
                        localStorage.setItem(cacheKey, JSON.stringify(html));
                        contentDiv.innerHTML = html;
                    }
                }
            };
            xhr.send();
        }

        function closePrayer() {
            currentView = 'list';
            document.getElementById('app-header').innerText = "Daily Prayers";
            document.getElementById('detail-view').style.display = 'none';
            document.getElementById('list-view').style.display = 'block';
            document.getElementById('soft-center').innerText = "SELECT";
            document.getElementById('soft-right').innerText = "Exit";
            
            // Re-center on the last selected item
            updateSelection(currentIndex);
        }

        // --- NETWORK & PARSING ---

        function fetchHomeData() {
            var xhr = new XMLHttpRequest({ mozSystem: true });
            xhr.open("GET", BASE_URL + "?t=" + Date.now(), true);
            xhr.onload = function() {
                if(xhr.status===200||xhr.status===0) {
                    var data = parseHome(xhr.responseText);
                    if(data.length>0) {
                        localStorage.setItem(CACHE_HOME, JSON.stringify(data));
                        renderList(data);
                        showToast(null);
                    }
                }
            };
            xhr.onerror = function() {
                if(!localStorage.getItem(CACHE_HOME)) document.getElementById('loading-msg').innerText = "No Internet";
                else showToast("Offline Mode");
            };
            xhr.send();
        }

        function loadHomeFromCache() {
            var d = localStorage.getItem(CACHE_HOME);
            if(d) renderList(JSON.parse(d));
        }

        function parseHome(html) {
            var parser = new DOMParser();
            var doc = parser.parseFromString(html, "text/html");
            var links = doc.body.querySelectorAll("a");
            var data = [];
            var seen = [];

            for(var i=0; i<links.length; i++) {
                var t = links[i].innerText.trim();
                var h = links[i].getAttribute('href');
                if(!h || h.indexOf('javascript')!==-1 || h.indexOf('#')===0) continue;
                var u = h.startsWith("http") ? h : BASE_URL + h;
                if(seen.indexOf(u)!==-1) continue;
                
                var l = u.toLowerCase();
                if (l.indexOf("sunday.html")!==-1) t="Sunday";
                else if (l.indexOf("monday.html")!==-1) t="Monday";
                else if (l.indexOf("tuesday.html")!==-1) t="Tuesday";
                else if (l.indexOf("wednesday.html")!==-1) t="Wednesday";
                else if (l.indexOf("thursday.html")!==-1) t="Thursday";
                else if (l.indexOf("friday.html")!==-1) t="Friday";
                else if (l.indexOf("saturday.html")!==-1) t="Saturday";

                if (t.length<2 || t.toLowerCase().indexOf("download")!==-1) continue;
                seen.push(u);
                data.push({text:t, url:u});
            }
            return data;
        }

        function parseDetail(html) {
            var parser = new DOMParser();
            var doc = parser.parseFromString(html, "text/html");
            var c = doc.querySelector(".contentLeftinside") || doc.body;
            return c.innerHTML;
        }

        function toggleTheme() {
            var b = document.body;
            if(b.classList.contains('dark-mode')) {
                b.classList.remove('dark-mode');
                localStorage.setItem(CACHE_THEME, 'light');
            } else {
                b.classList.add('dark-mode');
                localStorage.setItem(CACHE_THEME, 'dark');
            }
        }

        function showToast(m) {
            var t=document.getElementById('toast');
            if(m){t.innerText=m;t.style.display="block";setTimeout(function(){t.style.display="none"},2000);}
            else t.style.display="none";
        }